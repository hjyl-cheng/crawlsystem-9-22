# A1–S3 外围验收记录
状态初始全部 NOT_RUN。看到 Running 不等于以下项目通过。

| ID | 验收 | 状态 | 证据／日期 |
|---|---|---|---|
| INFRA-01 | 六台私网地址与OS/架构一致 | NOT_RUN | |
| INFRA-02 | 双向私网连通、时延、MTU与云安全组 | NOT_RUN | |
| INFRA-03 | 六台之外验证敏感端口未公开 | NOT_RUN | |
| INFRA-04 | 固定版本与实际imageID一致 | NOT_RUN | |
| INFRA-05 | 六节点Ready及三etcd健康 | NOT_RUN | |
| INFRA-06 | 跨节点Pod/DNS及WireGuard计数 | NOT_RUN | |
| INFRA-07 | PV目录/权限/宿主机磁盘余量 | NOT_RUN | |
| INFRA-08 | PG两实例实际同步状态 | NOT_RUN | |
| INFRA-09 | PgBouncer TLS/事务池/总连接预算 | NOT_RUN | |
| INFRA-10 | 数据库与角色访问隔离 | NOT_RUN | |
| INFRA-11 | Temporal schema Job和mTLS | NOT_RUN | |
| INFRA-12 | 最小Workflow＋Activity返回INFRA_OK | NOT_RUN | |
| INFRA-13 | 三Kafka副本跨节点/ISR | NOT_RUN | |
| INFRA-14 | Kafka认证与拒绝未授权访问 | NOT_RUN | |
| INFRA-15 | Debezium单表和slot状态 | NOT_RUN | |
| INFRA-16 | PG Outbox测试记录到Kafka | NOT_RUN | |
| INFRA-17 | CDC暂停/恢复和切主接点 | NOT_RUN | |
| INFRA-18 | ClickHouse TLS/版本/读写 | NOT_RUN | |
| INFRA-19 | 监控Targets可见及未覆盖项记录 | NOT_RUN | |
| INFRA-20 | 告警实际送达和恢复通知 | NOT_RUN | |
| INFRA-21 | 集中日志限额/轮转/敏感信息检查 | NOT_RUN | |
| INFRA-22 | NetworkPolicy正向和拒绝测试 | NOT_RUN | |
| INFRA-23 | PG远端备份成功 | NOT_RUN | |
| INFRA-24 | 新资源恢复备份并核对数据 | NOT_RUN | |
| INFRA-25 | etcd远端快照和恢复Token备份 | NOT_RUN | |
| INFRA-26 | S3权限/上传下载/保留测试 | NOT_RUN | |
| INFRA-27 | 空载24小时资源和磁盘增长记录 | NOT_RUN | |
| INFRA-28 | 小负载24小时有效写入/净增长 | NOT_RUN | |
| INFRA-29 | N-1及逐节点重启恢复边界 | NOT_RUN | |
| INFRA-30 | 交接endpoint/版本/权限/未通过项目 | NOT_RUN | |
