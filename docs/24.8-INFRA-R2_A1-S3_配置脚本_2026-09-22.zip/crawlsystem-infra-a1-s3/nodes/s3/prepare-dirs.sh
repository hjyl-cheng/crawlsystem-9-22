#!/usr/bin/env bash
set -euo pipefail
[[ ${EUID} -eq 0 ]] || { echo "Run with sudo" >&2; exit 1; }
if [[ -d "/srv/crawl-data/kafka" ]] && [[ -n "$(find "/srv/crawl-data/kafka" -mindepth 1 -maxdepth 1 -print -quit)" ]]; then
  echo "Non-empty directory, no ownership change: /srv/crawl-data/kafka"
else install -d -m 0750 -o 1001 -g 0 "/srv/crawl-data/kafka"; fi
if [[ -d "/srv/crawl-data/clickhouse" ]] && [[ -n "$(find "/srv/crawl-data/clickhouse" -mindepth 1 -maxdepth 1 -print -quit)" ]]; then
  echo "Non-empty directory, no ownership change: /srv/crawl-data/clickhouse"
else install -d -m 0750 -o 101 -g 101 "/srv/crawl-data/clickhouse"; fi
df -h / /srv 2>/dev/null || df -h /
