#!/usr/bin/env bash
set -euo pipefail
[[ ${EUID} -eq 0 ]] || { echo "Run with sudo" >&2; exit 1; }
if [[ -d "/srv/crawl-data/pg" ]] && [[ -n "$(find "/srv/crawl-data/pg" -mindepth 1 -maxdepth 1 -print -quit)" ]]; then
  echo "Non-empty directory, no ownership change: /srv/crawl-data/pg"
else install -d -m 0750 -o 26 -g 26 "/srv/crawl-data/pg"; fi
if [[ -d "/srv/crawl-data/prometheus" ]] && [[ -n "$(find "/srv/crawl-data/prometheus" -mindepth 1 -maxdepth 1 -print -quit)" ]]; then
  echo "Non-empty directory, no ownership change: /srv/crawl-data/prometheus"
else install -d -m 0750 -o 65534 -g 65534 "/srv/crawl-data/prometheus"; fi
if [[ -d "/srv/crawl-data/grafana" ]] && [[ -n "$(find "/srv/crawl-data/grafana" -mindepth 1 -maxdepth 1 -print -quit)" ]]; then
  echo "Non-empty directory, no ownership change: /srv/crawl-data/grafana"
else install -d -m 0750 -o 472 -g 472 "/srv/crawl-data/grafana"; fi
if [[ -d "/srv/crawl-data/alertmanager" ]] && [[ -n "$(find "/srv/crawl-data/alertmanager" -mindepth 1 -maxdepth 1 -print -quit)" ]]; then
  echo "Non-empty directory, no ownership change: /srv/crawl-data/alertmanager"
else install -d -m 0750 -o 65534 -g 65534 "/srv/crawl-data/alertmanager"; fi
df -h / /srv 2>/dev/null || df -h /
