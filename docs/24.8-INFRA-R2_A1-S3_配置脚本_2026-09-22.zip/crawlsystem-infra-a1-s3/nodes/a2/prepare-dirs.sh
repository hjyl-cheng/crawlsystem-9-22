#!/usr/bin/env bash
set -euo pipefail
[[ ${EUID} -eq 0 ]] || { echo "Run with sudo" >&2; exit 1; }
if [[ -d "/srv/crawl-data/pg" ]] && [[ -n "$(find "/srv/crawl-data/pg" -mindepth 1 -maxdepth 1 -print -quit)" ]]; then
  echo "Non-empty directory, no ownership change: /srv/crawl-data/pg"
else install -d -m 0750 -o 26 -g 26 "/srv/crawl-data/pg"; fi
if [[ -d "/srv/crawl-data/loki" ]] && [[ -n "$(find "/srv/crawl-data/loki" -mindepth 1 -maxdepth 1 -print -quit)" ]]; then
  echo "Non-empty directory, no ownership change: /srv/crawl-data/loki"
else install -d -m 0750 -o 10001 -g 10001 "/srv/crawl-data/loki"; fi
df -h / /srv 2>/dev/null || df -h /
